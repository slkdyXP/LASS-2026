# LASS 2026 LaTeX submission skeleton

This is a minimal project derived from the official ACM `acmart` v2.20
package. It targets the LASS 2026 requirement to use the ACM CIKM 2026
two-column format.

## Start here

1. Upload the contents of this directory (or the packaged ZIP) to Overleaf.
2. Set `main.tex` as the **Main document**.
3. Use pdfLaTeX and recompile.
4. Replace all placeholder text, results, CCS terms, keywords, and references.

The review copy uses:

```latex
\documentclass[sigconf,anonymous]{acmart}
```

This preserves the ACM `sigconf` two-column layout and hides author
information. Do not add identifying acknowledgments, repository URLs, PDF
metadata, or self-references written in the first person during double-blind
review.

## LASS 2026 checks

- Paper length: 4--8 pages, excluding references.
- Review: double-blind.
- Format: ACM CIKM 2026 / ACM two-column proceedings format.
- Submission system: OpenReview.
- Deadline published by LASS: August 30, 2026, 23:59 AoE.

Official pages checked on August 24, 2026:

- LASS 2026: <https://lassworkshop26.github.io/#cfp>
- CIKM 2026 submission information:
  <https://cikm2026.diag.uniroma1.it/full-research-papers/>
- ACM primary article template:
  <https://www.acm.org/publications/proceedings-template>

## Files retained

- `main.tex`: editable paper skeleton and main document.
- `references.bib`: example BibTeX database.
- `acmart.cls`: official ACM class file, v2.20.
- `ACM-Reference-Format.bst`: official ACM BibTeX style.
- `LICENSE`: license shipped with the ACM template.

The optional `teaserfigure` in `main.tex` reproduces the full-width first-page
figure arrangement seen in many ACM `sigconf` papers. Remove it if it does not
serve the paper.

## Camera-ready stage

After acceptance, wait for the organizers' instructions. Normally you will
remove `anonymous`, restore the real authors and affiliations, and insert the
rights, DOI, ISBN, and proceedings metadata supplied by ACM. Do not invent
camera-ready metadata in the review submission.
